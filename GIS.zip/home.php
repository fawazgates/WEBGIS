<div class="page-header">
    <h1>Sistem Informasi Geografis</h1>
</div>
<p>Aplikasi ini adalah tugas akhir dalam mata kuliah Manajemen Projeksi Sistem Informasi, Ekologi Laut, dan Kerekayasaan Informasi.</p>
<p>Informasi yang diberikan dalam aplikasi ini adalah informasi mengenai lokasi geografis PPN Kejawanan dan destinasi wisata sekitar jawabarat.</p>
<p>Selain itu terdapat juga forecasting atau peramalan mengenai data perikanan untuk 10 tahun kedepan di PPN Kejawanan dengan menggunakan Regresi Linear.</p>