<?php
//include dirname(__FILE__) . '/../config.php';

$config["server"]='localhost';
$config["username"]='bantenba_gis1';
$config["password"]='O$UZ)AtukFY]';
$config["database_name"]='bantenba_gis';