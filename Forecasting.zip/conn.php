<?php
	define('nim','1904224');
	$conn = new mysqli('localhost','bantenba_forecasting1','Xmk^Pq5=oBo#','bantenba_forecasting');
?>